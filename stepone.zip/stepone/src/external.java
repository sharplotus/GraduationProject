import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class external {
	public static Configuration configuration;
	public static Connection connection;
	public static Admin admin;

	// 主函数中的语句请逐句执行，只需删除其前的//即可，如：执行insertRow时请将其他语句注释
	public static void main(String[] args) throws IOException {
		long startTime = new Date().getTime();

		// 创建configuration对象
		Configuration conf = new Configuration();
		// 配置在etc/hadoop/core-site.xml fs.defaultFS
		conf.set("fs.defaultFS", "hdfs://192.168.1.117:9000");
		//conf.set("fs.defaultFS", "hdfs://127.0.0.1:9000");
		conf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
		// 创建FileSystem对象
		// 查看hdfs集群服务器/user/passwd.txt的内容
		FileSystem fs = FileSystem.get(conf);

		String path = "hdfs://192.168.1.117:9000/zhangheng/out.csv";
		//String path = "hdfs://127.0.0.1:9000/zhangheng/test3000";
		// String path = "/home/hadoop/test3000";
		// 读取文件内容
		FSDataInputStream is = fs.open(new Path(path));

		// 创建一个表
		String tablename = "external";
		deleteTable(tablename);
		createTable(tablename, new String[] { "date_ip", "total", "hour_1",
				"hour_2", "hour_3", "hour_4", "hour_5", "hour_6",
				"hour_7", "hour_8", "hour_9", "hour_10", "hour_11",
				"hour_12", "hour_13", "hour_14", "hour_15", "hour_16",
				"hour_17", "hour_18", "hour_19", "hour_20", "hour_21",
				"hour_22", "hour_23", "hour_24" });

		String lineString;
		int id=0;

		while ((lineString = is.readLine()) != null) {
			
			// 获取文件中的每一行数据
			
			// 获取每个数值
			String temp[] = lineString.split("\t");
			String row_ip = temp[10];

			String src = temp[2];
			String dst = temp[4];
			// 判断内部外部ip
			if (internalIP(src) && internalIP(dst)) {
				continue;
			} else if (internalIP(src)) {
				row_ip = dst;
			} else if (internalIP(dst)) {
				row_ip = src;
			}

			System.out.println(++id);
			// 计算日期
			double ts_usec = Double.valueOf(temp[0]);
			long timelong = Math.round(ts_usec);
			timelong *= 1000;
			java.util.Date date = new java.util.Date();
			date.setTime(timelong);
			SimpleDateFormat day = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat clock = new SimpleDateFormat("HH");
			String daystString = day.format(date);
			String clockstString = clock.format(date);

			// ap映射表
			String host = temp[8];
			insertRow(tablename, daystString + " " + row_ip, "total", "host",
					host);

			// 已有的包的数量
			int pack_num = Integer.valueOf(getDatanum(tablename, daystString
					+ " " + row_ip, "total", "total_num"));
			pack_num++;
			insertRow(tablename, daystString + " " + row_ip, "total",
					"total_num", String.valueOf(pack_num));

			int hourpack_num = Integer
					.valueOf(getDatanum(
							tablename,
							daystString + " " + row_ip,
							"hour_"
									+ String.valueOf(Integer
											.valueOf(clockstString) + 1),
							"hour_"
									+ String.valueOf(Integer
											.valueOf(clockstString) + 1)
									+ "_num"));
			hourpack_num++;
			insertRow(
					tablename,
					daystString + " " + row_ip,
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1),
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1)
							+ "_num", String.valueOf(hourpack_num));

			// 已有大小
			BigInteger ori_len = BigInteger.valueOf(Long.valueOf(temp[9]));
			BigInteger pack_len = BigInteger.valueOf(Long
					.valueOf(getDatanum(tablename, daystString + " " + row_ip,
							"total", "total_len")));
			pack_len = pack_len.add(ori_len);
			insertRow(tablename, daystString + " " + row_ip, "total",
					"total_len", String.valueOf(pack_len));

			BigInteger hourpack_len = BigInteger.valueOf(Long
					.valueOf(getDatanum(
							tablename,
							daystString + " " + row_ip,
							"hour_"
									+ String.valueOf(Integer
											.valueOf(clockstString) + 1),
							"hour_"
									+ String.valueOf(Integer
											.valueOf(clockstString) + 1)
									+ "_len")));
			hourpack_len = hourpack_len.add(ori_len);
			insertRow(
					tablename,
					daystString + " " + row_ip,
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1),
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1)
							+ "_len", String.valueOf(hourpack_len));
			
			//speed
			long speed=hourpack_len.longValue()*8/1000000;
			speed/=3600;
			insertRow(
					tablename,
					daystString + " " + row_ip,
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1),
					"hour_"
							+ String.valueOf(Integer.valueOf(clockstString) + 1)
							+ "_speed", String.valueOf(speed));

		}

		System.out.println(fs.getClass().getName());
		long endTime = new Date().getTime();
		System.out.println(endTime - startTime);
	}

	// 判断ip是否为内网ip
	public static boolean internalIP(String ip) {
		byte[] addr = new byte[4];
		String[] addStrings = ip.split("\\.");
		for (int i = 0; i < 2; i++) {
			int temp = Integer.valueOf(addStrings[i]);
			addr[i] = (byte) temp;
		}

		return internalIP(addr);
	}

	public static boolean internalIP(byte[] addr) {

		final byte b0 = addr[0];
		final byte b1 = addr[1];
		// 10.x.x.x/8
		final byte SECTION_1 = 0x0A;
		// 172.16.x.x/12
//		final byte SECTION_2 = (byte) 0xAC;
//		final byte SECTION_3 = (byte) 0x10;
//		final byte SECTION_4 = (byte) 0x1F;
//		// 192.168.x.x/16
//		final byte SECTION_5 = (byte) 0xC0;
//		final byte SECTION_6 = (byte) 0xA8;
		switch (b0) {
		case SECTION_1:
			return true;
//		case SECTION_2:
//			if (b1 >= SECTION_3 && b1 <= SECTION_4) {
//				return true;
//			}
//		case SECTION_5:
//			switch (b1) {
//			case SECTION_6:
//				return true;
//			}
		default:
			return false;
		}
	}

	// 建立连接
	public static void init() {
		configuration = HBaseConfiguration.create();
		//configuration.set("hbase.rootdir", "hdfs://localhost:9000/hbase");
		configuration.set("hbase.rootdir", "hdfs://192.168.1.117:9000/hbase");
		try {
			connection = ConnectionFactory.createConnection(configuration);
			admin = connection.getAdmin();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 关闭连接
	public static void close() {
		try {
			if (admin != null) {
				admin.close();
			}
			if (null != connection) {
				connection.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 建表。HBase的表中会有一个系统默认的属性作为主键，主键无需自行创建，默认为put命令操作中表名后第一个数据，因此此处无需创建id列
	 * 
	 * @param myTableName
	 *            表名
	 * @param colFamily
	 *            列族名
	 * @throws IOException
	 */
	public static void createTable(String myTableName, String[] colFamily)
			throws IOException {

		init();
		TableName tableName = TableName.valueOf(myTableName);

		if (admin.tableExists(tableName)) {
			System.out.println("talbe is exists!");
		} else {
			HTableDescriptor hTableDescriptor = new HTableDescriptor(tableName);
			for (String str : colFamily) {
				HColumnDescriptor hColumnDescriptor = new HColumnDescriptor(str);
				hTableDescriptor.addFamily(hColumnDescriptor);
			}
			admin.createTable(hTableDescriptor);
			System.out.println("create table success");
		}
		close();
	}

	/**
	 * 删除指定表
	 * 
	 * @param tableName
	 *            表名
	 * @throws IOException
	 */
	public static void deleteTable(String tableName) throws IOException {
		init();
		TableName tn = TableName.valueOf(tableName);
		if (admin.tableExists(tn)) {
			admin.disableTable(tn);
			admin.deleteTable(tn);
		}
		close();
	}

	/**
	 * 查看已有表
	 * 
	 * @throws IOException
	 */
	public static void listTables() throws IOException {
		init();
		HTableDescriptor hTableDescriptors[] = admin.listTables();
		for (HTableDescriptor hTableDescriptor : hTableDescriptors) {
			System.out.println(hTableDescriptor.getNameAsString());
		}
		close();
	}

	/**
	 * 向某一行的某一列插入数据
	 * 
	 * @param tableName
	 *            表名
	 * @param rowKey
	 *            行键
	 * @param colFamily
	 *            列族名
	 * @param col
	 *            列名（如果其列族下没有子列，此参数可为空）
	 * @param val
	 *            值
	 * @throws IOException
	 */
	public static void insertRow(String tableName, String rowKey,
			String colFamily, String col, String val) throws IOException {
		init();
		Table table = connection.getTable(TableName.valueOf(tableName));
		Put put = new Put(rowKey.getBytes());
		put.addColumn(colFamily.getBytes(), col.getBytes(), val.getBytes());
		table.put(put);
		table.close();
		close();
	}

	/**
	 * 删除数据
	 * 
	 * @param tableName
	 *            表名
	 * @param rowKey
	 *            行键
	 * @param colFamily
	 *            列族名
	 * @param col
	 *            列名
	 * @throws IOException
	 */
	public static void deleteRow(String tableName, String rowKey,
			String colFamily, String col) throws IOException {
		init();
		Table table = connection.getTable(TableName.valueOf(tableName));
		Delete delete = new Delete(rowKey.getBytes());
		// 删除指定列族的所有数据
		// delete.addFamily(colFamily.getBytes());
		// 删除指定列的数据
		// delete.addColumn(colFamily.getBytes(), col.getBytes());

		table.delete(delete);
		table.close();
		close();
	}

	/**
	 * 根据行键rowkey查找数据
	 * 
	 * @param tableName
	 *            表名
	 * @param rowKey
	 *            行键
	 * @param colFamily
	 *            列族名
	 * @param col
	 *            列名
	 * @throws IOException
	 */
	public static void getData(String tableName, String rowKey,
			String colFamily, String col) throws IOException {
		init();
		Table table = connection.getTable(TableName.valueOf(tableName));
		Get get = new Get(rowKey.getBytes());
		get.addColumn(colFamily.getBytes(), col.getBytes());
		Result result = table.get(get);
		showCell(result);
		table.close();
		close();
	}

	/**
	 * 根据行键rowkey查找数据（非格式化输出，返回内容）
	 * 
	 * @param tableName
	 *            表名
	 * @param rowKey
	 *            行键
	 * @param colFamily
	 *            列族名
	 * @param col
	 *            列名
	 * @throws IOException
	 */
	public static String getDatanum(String tableName, String rowKey,
			String colFamily, String col) throws IOException {
		init();
		Table table = connection.getTable(TableName.valueOf(tableName));
		Get get = new Get(rowKey.getBytes());
		get.addColumn(colFamily.getBytes(), col.getBytes());
		Result result = table.get(get);
		Cell[] cells = result.rawCells();

		if (cells.length == 0) {
			return "0";
		}
		Cell cell = cells[cells.length - 1];
		String valueString = new String(CellUtil.cloneValue(cell));
		table.close();
		close();
		return valueString;

	}

	/**
	 * 格式化输出
	 * 
	 * @param result
	 */
	public static void showCell(Result result) {
		Cell[] cells = result.rawCells();
		for (Cell cell : cells) {
			System.out.println("RowName:" + new String(CellUtil.cloneRow(cell))
					+ " ");
			System.out.println("Timetamp:" + cell.getTimestamp() + " ");
			System.out.println("column Family:"
					+ new String(CellUtil.cloneFamily(cell)) + " ");
			System.out.println("row Name:"
					+ new String(CellUtil.cloneQualifier(cell)) + " ");
			System.out.println("value:" + new String(CellUtil.cloneValue(cell))
					+ " ");
		}
	}
}